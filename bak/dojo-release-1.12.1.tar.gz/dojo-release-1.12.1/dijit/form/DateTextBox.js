//>>built
define("dijit/form/DateTextBox",["dojo/_base/declare","../Calendar","./_DateTimeTextBox"],function(a,b,c){return a("dijit.form.DateTextBox",c,{baseClass:"dijitTextBox dijitComboBox dijitDateTextBox",popupClass:b,_selector:"date",maxHeight:Infinity,value:new Date("")})});
//# sourceMappingURL=DateTextBox.js.map