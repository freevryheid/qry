//>>built
define("dijit/form/nls/mk/ComboBox",{previousMessage:"\u041f\u0440\u0435\u0442\u0445\u043e\u0434\u043d\u0438 \u0438\u0437\u0431\u043e\u0440\u0438",nextMessage:"\u041f\u043e\u0432\u0435\u045c\u0435 \u0438\u0437\u0431\u043e\u0440\u0438"});
//# sourceMappingURL=ComboBox.js.map