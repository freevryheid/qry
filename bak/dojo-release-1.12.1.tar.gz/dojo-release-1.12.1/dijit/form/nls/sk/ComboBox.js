//>>built
define("dijit/form/nls/sk/ComboBox",{previousMessage:"Predch\u00e1dzaj\u00face mo\u017enosti",nextMessage:"Viac mo\u017enost\u00ed"});
//# sourceMappingURL=ComboBox.js.map