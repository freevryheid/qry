//>>built
define("dijit/form/nls/hu/ComboBox",{previousMessage:"El\u0151z\u0151 men\u00fcpontok",nextMessage:"Tov\u00e1bbi men\u00fcpontok"});
//# sourceMappingURL=ComboBox.js.map