define("dijit/form/nls/bs/validate", {      
//begin v1.x content
	invalidMessage: "Unešena vrijednost je neispravna",
	missingMessage: "Ova vrijednost je obavezna",
	rangeMessage: "Ova vrijednost je izvan raspona."
//end v1.x content
});

