define("dijit/form/nls/bs/ComboBox", {      
//begin v1.x content
		previousMessage: "Prethodni izbori",
		nextMessage: "Još izbora"
//end v1.x content
});

