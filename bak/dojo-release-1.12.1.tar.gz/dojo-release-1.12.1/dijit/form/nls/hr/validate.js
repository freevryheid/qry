//>>built
define("dijit/form/nls/hr/validate",{invalidMessage:"Unesena vrijednost nije va\u017ee\u0107a.",missingMessage:"Potrebna je ova vrijednost.",rangeMessage:"Ova vrijednost je izvan raspona."});
//# sourceMappingURL=validate.js.map