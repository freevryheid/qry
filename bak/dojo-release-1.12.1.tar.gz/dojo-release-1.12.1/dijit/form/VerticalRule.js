//>>built
define("dijit/form/VerticalRule",["dojo/_base/declare","./HorizontalRule"],function(a,b){return a("dijit.form.VerticalRule",b,{templateString:'\x3cdiv class\x3d"dijitRuleContainer dijitRuleContainerV"\x3e\x3c/div\x3e',_positionPrefix:'\x3cdiv class\x3d"dijitRuleMark dijitRuleMarkV" style\x3d"top:',_isHorizontal:!1})});
//# sourceMappingURL=VerticalRule.js.map