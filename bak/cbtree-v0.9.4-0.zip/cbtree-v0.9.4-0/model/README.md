#### CheckBox Tree Models and Extensions ####

This directory contains cbtree Store Models and extension for the use with the 
new dojo/store and cbtree/store Object Stores.
Please be adviced that as of dojo 2.0 these will be the only supported CheckBox
Tree Models.
