#### Deprecated Store Models ####

This directory contains cbtree Store Models and API's for the use with the legacy 
dojo/data stores. These models are <strong>deprecated</strong> and will be removed
with the release of dojo 2.0. 
Please refer to cbtree/model for new implementations based on the dojo/store and
cbtree/store stores.
